package com.example.clonbereal

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.clonbereal.adapter.BeRealAdapter
import com.example.clonbereal.databinding.ActivityMainBinding
import com.example.clonbereal.data.BeRealPost
import java.text.SimpleDateFormat
import java.util.*
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.app.AlertDialog
import android.widget.ImageView
import android.widget.LinearLayout
import android.view.Gravity
import android.app.Dialog
import android.view.Window
import com.example.clonbereal.databinding.DialogPreviewBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: BeRealAdapter

    // Variable temporal para guardar la primera foto mientras tomamos la segunda
    private var tempMainPhoto: Bitmap? = null

    // 2. Intent para la Selfie (Cámara Frontal)

    private val takeSelfieLauncher = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null && tempMainPhoto != null) {

            // 1. CREAMOS EL DIÁLOGO DE PREVISUALIZACIÓN
            val builder = AlertDialog.Builder(this)
            builder.setTitle("¿Publicar tu BeReal?")

            // Creamos un layout programático para mostrar las fotos
            val layout = LinearLayout(this)
            layout.orientation = LinearLayout.VERTICAL
            layout.gravity = Gravity.CENTER

            val imgPreviewMain = ImageView(this)
            imgPreviewMain.setImageBitmap(tempMainPhoto)
            imgPreviewMain.layoutParams = LinearLayout.LayoutParams(600, 800) // Ajusta tamaño
            layout.addView(imgPreviewMain)

            val imgPreviewSelfie = ImageView(this)
            imgPreviewSelfie.setImageBitmap(bitmap)
            imgPreviewSelfie.layoutParams = LinearLayout.LayoutParams(300, 400)
            layout.addView(imgPreviewSelfie)

            builder.setView(layout)

            // 2. BOTONES DE ACCIÓN
            builder.setPositiveButton("Publicar") { _, _ ->
                // Aquí es donde realmente se sube a la lista
                guardarPostEnFeed(tempMainPhoto!!, bitmap)
                tempMainPhoto = null
            }

            builder.setNegativeButton("Retomar") { _, _ ->
                tempMainPhoto = null
                Toast.makeText(this, "Captura cancelada", Toast.LENGTH_SHORT).show()
            }

            builder.show()

        } else {
            Toast.makeText(this, "Error al capturar", Toast.LENGTH_SHORT).show()
        }
    }

    // Función auxiliar para mantener limpio el código
    private fun guardarPostEnFeed(main: Bitmap, selfie: Bitmap) {
        val timeNow = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        val newPost = BeRealPost(
            id = UUID.randomUUID().toString(),
            userAvatarResId = R.drawable.ic_launcher_foreground,
            username = "felipe.herreraw",
            timePosted = timeNow,
            mainImageBitmap = main,
            selfieImageBitmap = selfie,
            reactionCount = 0,
            commentCount = 0
        )
        val currentList = adapter.currentList.toMutableList()
        currentList.add(0, newPost)
        adapter.submitList(currentList)
    }
    // 1. Intent para la Cámara Principal (Trasera)
    private val takeMainPhotoLauncher = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            // Guardamos la foto trasera temporalmente
            tempMainPhoto = bitmap
            Toast.makeText(this, "¡Ahora la Selfie!", Toast.LENGTH_SHORT).show()

            // Inmediatamente lanzamos la cámara de nuevo para la selfie
            takeSelfieLauncher.launch(null)
        } else {
            Toast.makeText(this, "Se canceló la captura", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.black)

        setupRecyclerView()

        // Configurar el botón de la cámara (Asegúrate de que el ID coincida con tu XML)
        // Y en tu onCreate, cambia el onClickListener del botón:
        binding.btnCamera.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                takeMainPhotoLauncher.launch(null)
            } else {
                requestPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = BeRealAdapter()
        binding.recyclerViewFeed.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewFeed.adapter = adapter
        // No cargamos datos simulados, la lista empieza VACÍA como pediste.
    }

    private fun showPreviewDialog(main: Bitmap, selfie: Bitmap) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        // Inflamos tu XML de diseño
        val bindingPreview = DialogPreviewBinding.inflate(layoutInflater)
        dialog.setContentView(bindingPreview.root)

        // Llenamos las imágenes
        bindingPreview.imgMainPreview.setImageBitmap(main)
        bindingPreview.imgSelfiePreview.setImageBitmap(selfie)

        // Botón X (Descartar)
        bindingPreview.btnClose.setOnClickListener {
            dialog.dismiss()
        }

        // Botón ENVIAR (Avión de papel)
        bindingPreview.btnSend.setOnClickListener {
            guardarPostEnFeed(main, selfie) // Esta función ya la tenías
            dialog.dismiss()
        }

        dialog.show()
        // Asegurar que el diálogo ocupe toda la pantalla
        dialog.window?.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
    }



    // Agrega este lanzador de permisos como propiedad de la clase
    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            takeMainPhotoLauncher.launch(null)
        } else {
            Toast.makeText(this, "Sin permiso de cámara no hay BeReal", Toast.LENGTH_SHORT).show()
        }
    }

}