package com.example.clonbereal.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.clonbereal.R
import com.example.clonbereal.databinding.ItemBerealPostBinding
import com.example.clonbereal.data.BeRealPost

class BeRealAdapter : ListAdapter<BeRealPost, BeRealAdapter.BeRealViewHolder>(BeRealDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BeRealViewHolder {
        val binding = ItemBerealPostBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BeRealViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BeRealViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class BeRealViewHolder(private val binding: ItemBerealPostBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(post: BeRealPost) {
            // Cabecera del post
            binding.imgUserAvatar.setImageResource(post.userAvatarResId)
            binding.tvUsername.text = post.username
            binding.tvTime.text = post.timePosted

            // ¡AQUÍ ESTÁ EL CAMBIO IMPORTANTE! Pintamos los Bitmaps reales de la cámara
            binding.imgMain.setImageBitmap(post.mainImageBitmap)
            binding.imgSelfie.setImageBitmap(post.selfieImageBitmap)

            // Reacciones y comentarios
            // Usamos un ícono de sistema genérico que siempre existe
            binding.imgReactionEmojis.setImageResource(android.R.drawable.ic_menu_add) // O cámbialo por un icono existente
            binding.tvReactionCount.text = post.reactionCount.toString()

            binding.tvCommentCount.text = "Ver los ${post.commentCount} comentarios..."

            // Avatar en la barra de "Añadir comentario"
            binding.imgCommentAvatar.setImageResource(post.userAvatarResId)
        }
    }

    class BeRealDiffCallback : DiffUtil.ItemCallback<BeRealPost>() {
        override fun areItemsTheSame(oldItem: BeRealPost, newItem: BeRealPost) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: BeRealPost, newItem: BeRealPost) = oldItem == newItem
    }
}