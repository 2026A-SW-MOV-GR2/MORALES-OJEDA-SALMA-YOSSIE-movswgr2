package com.example.clonbereal.data // (O el paquete que uses)

import android.graphics.Bitmap

data class BeRealPost(
    val id: String,
    val userAvatarResId: Int, // Este sí lo dejamos quemado para el perfil
    val username: String,
    val timePosted: String,
    val mainImageBitmap: Bitmap,   // ¡Cambiado a Bitmap real!
    val selfieImageBitmap: Bitmap, // ¡Cambiado a Bitmap real!
    val reactionCount: Int,
    val commentCount: Int
)